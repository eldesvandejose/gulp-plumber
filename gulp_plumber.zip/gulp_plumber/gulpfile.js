"use strict";
const gulp = require('gulp'), 
	sass = require('gulp-sass'), 
	plumber = require('gulp-plumber'), 
	autoprefixer = require('gulp-autoprefixer');
 
gulp.task ('sass-compile', ()=>
	gulp.src('./scss/*.scss').
		pipe(plumber()).
		pipe(sass({
			outputStyle: "expanded", 
			sourceComments: true
		})).
		pipe(autoprefixer()).
		pipe(gulp.dest('./css'))
);

gulp.task('default', ()=>{
	gulp.watch('./scss/*.scss', ['sass-compile']);
});